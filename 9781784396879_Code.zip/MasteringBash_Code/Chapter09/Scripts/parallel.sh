#!/bin/bash

(while true
do
	:
done)&

(for i in {1..3}
do
	echo "$i"
done)
