#!/bin/bash

cat << DELIMITER
This is a string
followed by another
until the 
DELIMITER
