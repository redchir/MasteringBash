#!/bin/bash

today=$(date +%Y.%m.%d)
cat <<< $today
