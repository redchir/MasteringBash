#!/bin/bash

x=32
y=5
: ${x?} ${y?} ${z?}
