#!/bin/bash

# I am a comment at the beginning of a line`
ls # I am a comment after a command
#I am a comment preceeding a command and so it is not interpreted ps
echo # I am a comment but you cannot see me
echo \# I am a comment but you can see me
