#!/bin/bash

i=0
for cities 
do
	echo "City $((i++)) is: $cities"
done
exit 0
