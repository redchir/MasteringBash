#!/bin/bash

for i in {10..1..2}
do
	echo "$i"
done
