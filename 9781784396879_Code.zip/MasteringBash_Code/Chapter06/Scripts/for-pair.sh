#!/bin/bash

for cities in Belfast UK Redwood USA Milan ITALY Paris FRANCE
do
	echo "$cities is in $cities"
done
exit 0
