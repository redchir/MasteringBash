#!/bin/bash

i=1
while (( i <= 5))
do
	echo "$i"
	((i++))
done
