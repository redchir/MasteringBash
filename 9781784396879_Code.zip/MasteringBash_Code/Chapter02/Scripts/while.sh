#!/bin/bash

while true; do

echo ${$}

done
