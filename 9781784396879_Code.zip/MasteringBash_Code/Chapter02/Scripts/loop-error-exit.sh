#!/bin/bash

counter=10

while [ $counter -gt 0 ]; 
	do
        echo "Loop number: $((counter--))"
        fsaapoiwe
        done
exit 20
