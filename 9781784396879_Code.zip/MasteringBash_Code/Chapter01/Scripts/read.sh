echo "The content of read.me file is"
cat read.me
