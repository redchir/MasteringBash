#!/bin/bash

export MYTEST=NOWAY

env | grep MYTEST

echo ${MYTEST}
